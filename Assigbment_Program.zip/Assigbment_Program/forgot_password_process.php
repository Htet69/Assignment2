<?php
session_start();
include 'db_connection.php';
require 'vendor/autoload.php';
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check for maximum attempts before proceeding
    if (isset($_SESSION['attempts']) && $_SESSION['attempts'] >= 5) {
        $time_since_last_attempt = time() - $_SESSION['last_attempt_time'];
        $wait_time = 30 + ($_SESSION['attempts'] - 4) * 10; // Delay increases after each failed attempt

        // If not enough time has passed, prevent further action
        if ($time_since_last_attempt < $wait_time) {
            $_SESSION['message'] = "You must wait before trying again.";
            header("Location: forgot_password.php");
            exit();
        } else {
            // Reset attempts after cooldown
            $_SESSION['attempts'] = 0;
            $_SESSION['last_attempt_time'] = time(); // Reset last attempt time
        }
    }

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $token = bin2hex(random_bytes(16));
        $expires = date("Y-m-d H:i:s", strtotime('+1 hour'));

        $sql = "UPDATE users SET reset_token='$token', reset_token_expires='$expires' WHERE email='$email'";
        $conn->query($sql);

        // Increase attempt count after each attempt
        $_SESSION['attempts'] += 1;
        $_SESSION['last_attempt_time'] = time();

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'htetmyatpaswordrest@gmail.com';  
            $mail->Password = 'vrmw dvtl akvn rnnl';
            $mail->SMTPSecure = 'tls'; // Use 'tls' or 'ssl' based on your provider
            $mail->Port = 587; // Port number for 'tls', or 465 for 'ssl'

            $mail->setFrom('TestApp@gmail.com'); 
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Request';
            $mail->Body = "Click <a href='http://localhost/Assigbment_Program/reset_password.php?token=$token'>here</a> to reset your password.";

            if ($mail->send()) {
                $_SESSION['message'] = "Check your email for the password reset link.";
            } else {
                $_SESSION['message'] = "Failed to send reset email.";
            }
        } catch (Exception $e) {
            $_SESSION['message'] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $_SESSION['message'] = "Email not found.";
    }

    $conn->close();
    header("Location: forgot_password.php");
    exit();
}
