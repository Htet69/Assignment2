<?php
session_start();
include 'db_connection.php';

$verificationMessage = '';
if (isset($_GET['token'])) {
    $token = mysqli_real_escape_string($conn, $_GET['token']);
    $sql = "SELECT * FROM users WHERE verification_token = '$token' AND verified = 0";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $update_sql = "UPDATE users SET verified = 1 WHERE verification_token = '$token'";
        if ($conn->query($update_sql) === TRUE) {
            $verificationMessage = "Your email has been verified successfully!";
        } else {
            $verificationMessage = "There was an error verifying your email.";
        }
    } else {
        $verificationMessage = "Invalid or expired verification link.";
    }
} else {
    $verificationMessage = "No verification token provided.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Email</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav>
    <a href="register.php">Register</a> |
    <a href="login.php">Login</a> |
</nav>
<div class="container">
    <h2>Email Verification</h2>
    <p><?php echo htmlspecialchars($verificationMessage); ?></p>
    <a href="login.php" class="btn">Login</a>
</div>

</body>
</html>
