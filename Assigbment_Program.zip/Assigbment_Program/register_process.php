<?php
session_start();
include 'db_connection.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';

$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    $captcha_input = strtoupper(trim($_POST['captcha_input'])); // Normalize case

    // CAPTCHA check
    if ($captcha_input !== $_SESSION['captcha']) {
        $errorMessage = "Incorrect CAPTCHA code!";
        header("Location: register.php?error=" . urlencode($errorMessage));
        exit;
    }

    // Check if the username already exists
    $sql_check_username = "SELECT * FROM users WHERE username='$username'";
    $result_check_username = $conn->query($sql_check_username);
    if ($result_check_username && $result_check_username->num_rows > 0) {
        $errorMessage = "Username already taken, try another one.";
        header("Location: register.php?error=" . urlencode($errorMessage));
        exit;
    }

    // Check if the email already exists
    $sql_check_email = "SELECT * FROM users WHERE email='$email'";
    $result_check_email = $conn->query($sql_check_email);
    if ($result_check_email && $result_check_email->num_rows > 0) {
        $errorMessage = "Email already exists!";
        header("Location: register.php?error=" . urlencode($errorMessage));
        exit;
    }

    // Password strength check
    $hasNumber = preg_match('/[0-9]/', $password);
    $hasCapital = preg_match('/[A-Z]/', $password);
    $hasSpecial = preg_match('/[\W]/', $password);
    $isValidLength = strlen($password) >= 9;

    if (!($isValidLength && $hasNumber && $hasCapital && $hasSpecial)) {
        $errorMessage = "Password must be at least 9 characters long, include at least one capital letter, one number, and one special character.";
        header("Location: register.php?error=" . urlencode($errorMessage));
        exit;
    }

    // Password match check
    if ($password !== $confirm_password) {
        $errorMessage = "Passwords do not match.";
        header("Location: register.php?error=" . urlencode($errorMessage));
        exit;
    }

    // Generate verification token
    $verification_token = bin2hex(random_bytes(16));

    // Insert data into the database
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    $sql = "INSERT INTO users (username, email, password, verification_token, verified) VALUES ('$username', '$email', '$hashed_password', '$verification_token', 0)";

    if ($conn->query($sql) === TRUE) {
        // Send verification email
        sendVerificationEmail($email, $verification_token);
        header("Location: register.php?message=" . urlencode("Registration successful! Please check your email to verify your account."));
        exit;
    } else {
        $errorMessage = "Error: " . $sql . "<br>" . $conn->error;
        header("Location: register.php?error=" . urlencode($errorMessage));
        exit;
    }
}

// Function to send verification email
function sendVerificationEmail($email, $token) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->SMTPDebug = 2; // Enable verbose debug output for troubleshooting
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'tls';
        $mail->Username = 'htetmyatpaswordrest@gmail.com';
        $mail->Password = 'vrmw dvtl akvn rnnl';

        // Recipients
        $mail->setFrom('htetmyatpaswordrest@gmail.com', 'Test App'); // Use a valid "From" address
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Verify Your Email';
        $mail->Body = 'Please click the following link to verify your email and complete your registration: <a href="http://localhost/Assigbment_Program/verify.php?token=' . $token . '">Verify Email</a>';

        $mail->send();
        echo 'Verification email sent successfully.';
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        echo "Message could not be sent. Please check server logs for details.";
    }
}

$conn->close();
?>
