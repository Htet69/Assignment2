// Function to check password strength and update requirement indicators
function checkPasswordStrength() {
    var password = document.getElementById('new_password').value;

    var hasNumber = /[0-9]/.test(password);
    var hasCapital = /[A-Z]/.test(password);
    var hasSpecial = /[\W]/.test(password);
    var isValidLength = password.length >= 9;

    updateRequirement('lengthRequirement', isValidLength);
    updateRequirement('numberRequirement', hasNumber);
    updateRequirement('capitalRequirement', hasCapital);
    updateRequirement('specialRequirement', hasSpecial);

    var strength = (isValidLength ? 1 : 0) + (hasNumber ? 1 : 0) + (hasCapital ? 1 : 0) + (hasSpecial ? 1 : 0);
    var strengthBar = document.getElementById('passwordStrength');
    var strengthMessage = "";

    switch (strength) {
        case 0:
        case 1:
            strengthMessage = "Very Weak";
            strengthBar.style.color = "red";
            break;
        case 2:
            strengthMessage = "Weak";
            strengthBar.style.color = "orange";
            break;
        case 3:
            strengthMessage = "Moderate";
            strengthBar.style.color = "yellow";
            break;
        case 4:
            strengthMessage = "Strong";
            strengthBar.style.color = "green";
            break;
        default:
            strengthMessage = "";
            break;
    }

    strengthBar.textContent = "Password strength: " + strengthMessage;
}

function updateRequirement(id, isValid) {
    var element = document.getElementById(id);
    if (isValid) {
        element.textContent = "✔️";
        element.style.color = "green";
    } else {
        element.textContent = "❌";
        element.style.color = "red";
    }
}

function checkPasswordMatch() {
    var password = document.getElementById('new_password').value;
    var confirmPassword = document.getElementById('confirm_password').value;
    var matchMessage = document.getElementById('passwordMatchMessage');

    if (password === confirmPassword) {
        matchMessage.textContent = "Passwords match!";
        matchMessage.style.color = "green";
    } else {
        matchMessage.textContent = "Passwords do not match!";
        matchMessage.style.color = "red";
    }
}

function validateForm(event) {
    var password = document.getElementById('new_password').value;
    var confirmPassword = document.getElementById('confirm_password').value;
    var criteriaError = document.getElementById('passwordCriteriaError');
    
    var hasNumber = /[0-9]/.test(password);
    var hasCapital = /[A-Z]/.test(password);
    var hasSpecial = /[\W]/.test(password);
    var isValidLength = password.length >= 9;

    criteriaError.textContent = "";

    if (!(isValidLength && hasNumber && hasCapital && hasSpecial)) {
        criteriaError.textContent = "Password must be at least 9 characters long, include at least one capital letter, one number, and one special character.";
        event.preventDefault(); 
        return false;
    }

    if (password !== confirmPassword) {
        criteriaError.textContent = "Passwords do not match.";
        event.preventDefault(); 
        return false;
    }

    return true;  
}

document.getElementById('registerForm').addEventListener('submit', validateForm);
document.getElementById('new_password').addEventListener('input', checkPasswordStrength);
document.getElementById('confirm_password').addEventListener('input', checkPasswordMatch);
