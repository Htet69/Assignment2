<?php 
session_start();
$captcha_code = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 6);
$_SESSION['captcha'] = $captcha_code;  // Store the CAPTCHA code in session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<div class="container">
    <h2>Create an Account</h2>

    <?php
    if (isset($_GET['error'])) {
        echo '<div style="color: red; border: 1px solid red; padding: 10px; margin-bottom: 10px; border-radius: 5px;">' . htmlspecialchars($_GET['error']) . '</div>';
    }

    if (isset($_GET['message'])) {
        echo '<div style="color: green; border: 1px solid green; padding: 10px; margin-bottom: 10px; border-radius: 5px;">' . htmlspecialchars($_GET['message']) . '</div>';
    }
    ?>

    <form id="registerForm" action="register_process.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required><br><br>

        <label for="new_password">Password:</label>
        <label>Password must be at least 9 characters long and contain numbers, uppercase letters, and special characters.</label>
        <input type="password" id="new_password" name="password" required>
        <div id="passwordStrength"></div><br>

        <ul class="password-requirements">
            <li><span id="lengthRequirement">❌</span> At least 9 characters</li>
            <li><span id="numberRequirement">❌</span> Contains a number</li>
            <li><span id="capitalRequirement">❌</span> Contains an uppercase letter</li>
            <li><span id="specialRequirement">❌</span> Contains a special character</li>
        </ul>

        <label for="confirm_password">Re-enter Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required>
        <div id="passwordMatchMessage"></div><br>

        <label>
            <input type="checkbox" id="showPassword"> Show Passwords
        </label><br><br>

        <label for="captcha">Please enter the CAPTCHA code below:</label><br>
        <canvas id="captchaCanvas" width="150" height="50"></canvas>
        <button type="button" id="refreshCaptcha" style="background: none; border: none;">
            <i class="fas fa-sync-alt"></i>
        </button>
        <br>
        <input type="text" id="captcha_input" name="captcha_input" required><br><br>

        <button type="submit">Register</button>
    </form>

    <p>Already have an account? <a href="login.php">Login here</a></p>
</div>

<script src="js/password_strength.js"></script>
<script>
    let captchaText = "<?php echo $_SESSION['captcha']; ?>";

    const canvas = document.getElementById("captchaCanvas");
    const ctx = canvas.getContext("2d");

    function drawCaptcha(captchaText) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = "24px Arial";
        ctx.textAlign = "center";

        for (let i = 0; i < captchaText.length; i++) {
            ctx.fillStyle = `hsl(${Math.random() * 360}, 80%, 50%)`;
            ctx.fillText(captchaText[i], 25 + i * 20, 35 + Math.random() * 10);
        }

        for (let i = 0; i < 5; i++) {
            ctx.strokeStyle = `hsl(${Math.random() * 360}, 70%, 40%)`;
            ctx.lineWidth = Math.random() * 2 + 1;
            ctx.beginPath();
            ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
            ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
            ctx.stroke();
        }
    }

    drawCaptcha(captchaText);

    document.getElementById("refreshCaptcha").addEventListener("click", () => {
        fetch('generate_captcha.php')
            .then(response => response.text())
            .then(newCaptcha => {
                captchaText = newCaptcha;
                drawCaptcha(captchaText);
            })
            .catch(error => {
                console.error('Error refreshing CAPTCHA:', error);
            });
    });

    document.getElementById("showPassword").addEventListener("change", function() {
        const passwordField = document.getElementById("new_password");
        const confirmPasswordField = document.getElementById("confirm_password");

        if (this.checked) {
            passwordField.type = "text"; 
            confirmPasswordField.type = "text"; 
        } else {
            passwordField.type = "password"; 
            confirmPasswordField.type = "password"; 
        }
    });
</script>
</body>
</html>
