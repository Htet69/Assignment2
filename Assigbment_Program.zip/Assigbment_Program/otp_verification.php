<?php
session_start();

// Initialize error message
$errorMessage = "";

// Check if OTP was sent
if (!isset($_SESSION['otp_sent'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userOtp = $_POST['otp'];

    // Check if the entered OTP matches the session OTP
    if ($userOtp == $_SESSION['otp']) {
        // OTP verified, allow login
        unset($_SESSION['otp']);  // Clear OTP from session
        unset($_SESSION['otp_sent']);  // Clear OTP sent flag
        header("Location: landing.php");  // Redirect to the dashboard or home page
        exit;
    } else {
        // Invalid OTP
        $errorMessage = "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="container">
    <h2>Verify Your OTP</h2>

    <?php
    if (!empty($errorMessage)) {
        echo "<div style='color: red; border: 1px solid red; padding: 10px; margin-bottom: 10px; border-radius: 5px;'>" . htmlspecialchars($errorMessage) . "</div>";
    }
    ?>

    <form action="otp_verification.php" method="post">
        <label for="otp">Enter OTP:</label>
        <input type="text" id="otp" name="otp" required><br><br>

        <button type="submit">Verify OTP</button>
    </form>

    <p><a href="login.php">Back to Login</a></p>
</div>
</body>
</html>
