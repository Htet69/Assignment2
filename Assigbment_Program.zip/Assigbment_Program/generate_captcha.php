<?php
session_start();
$captcha_code = '';
$captcha_code = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 6);
$_SESSION['captcha'] = $captcha_code;
echo $captcha_code;
for ($i = 0; $i < 6; $i++) {
    $captcha_code .= $chars[rand(0, strlen($chars) - 1)];
}
$_SESSION['captcha'] = $captcha_code;

header('Content-Type: image/png');
$im = imagecreate(150, 50);
$bg = imagecolorallocate($im, 255, 255, 255); 
$text_color = imagecolorallocate($im, 0, 0, 0);  
imagestring($im, 5, 30, 15, $captcha_code, $text_color);
imagepng($im);
imagedestroy($im);
?>
