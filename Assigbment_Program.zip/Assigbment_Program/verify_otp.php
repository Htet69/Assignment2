<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $enteredOtp = $_POST['otp'];
    if ($enteredOtp == $_SESSION['otp']) {
        // OTP verified, redirect to the user dashboard or home page
        unset($_SESSION['otp']); // Clear OTP from session
        header("Location: dashboard.php");
        exit;
    } else {
        // OTP is incorrect, show an error
        echo "Invalid OTP!";
    }
}
?>
