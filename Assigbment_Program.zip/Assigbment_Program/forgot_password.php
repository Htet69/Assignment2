<?php
session_start();
$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
unset($_SESSION['message']);  // Clear the message after displaying it

// Initialize attempt counter and timestamp if not set
if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 0;
    $_SESSION['last_attempt_time'] = time(); // Set last attempt time
}

// Restricting the user after 5 attempts
if ($_SESSION['attempts'] >= 5) {
    $time_since_last_attempt = time() - $_SESSION['last_attempt_time'];
    $wait_time = 30 + ($_SESSION['attempts'] - 4) * 10; // Delay increases after each failed attempt

    // Check if the user has waited enough time before they can try again
    if ($time_since_last_attempt < $wait_time) {
        $message = "You have reached the maximum number of attempts. Please wait for " . ($wait_time - $time_since_last_attempt) . " seconds before trying again.";
    } else {
        // Reset attempts after the wait time is over
        $_SESSION['attempts'] = 0; // Reset attempts
        $_SESSION['last_attempt_time'] = time(); // Reset last attempt time
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav>
    <a href="register.php">Register</a> | 
    <a href="login.php">Login</a> 
</nav>
    <div class="container">
        <h2>Recover Password</h2>
        
        <?php if ($message): ?>
            <div class="success-message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <form action="forgot_password_process.php" method="POST">
            <label for="email">Enter your email address:</label>
            <input type="text" name="email" id="email" required>
            
            <!-- Button is disabled if max attempts reached, wait time displayed -->
            <button type="submit" id="resetButton" <?php if ($_SESSION['attempts'] >= 5) echo 'disabled'; ?>>Send Reset Link</button>
            
            <!-- Show wait time if attempts exceeded -->
            <?php if ($_SESSION['attempts'] >= 5 && $time_since_last_attempt < $wait_time): ?>
                <p id="waitTimeMessage">Please wait for <?= $wait_time - $time_since_last_attempt ?> seconds.</p>
            <?php endif; ?>
        </form>
    </div>

    <script>
        // Ensure the DOM is fully loaded before running the script
        document.addEventListener('DOMContentLoaded', function () {
            const resetButton = document.getElementById("resetButton");

            // If the button is disabled and a wait time is active
            <?php if ($_SESSION['attempts'] >= 5 && $time_since_last_attempt < $wait_time): ?>
                const waitTime = <?= $wait_time - $time_since_last_attempt ?>;
                let remainingTime = waitTime;
                const waitTimeMessage = document.getElementById("waitTimeMessage");

                // Disable button and show countdown
                resetButton.disabled = true;

                // Countdown functionality
                const countdown = setInterval(function () {
                    if (remainingTime > 0) {
                        remainingTime--;
                        waitTimeMessage.textContent = "Please wait for " + remainingTime + " seconds.";
                    } else {
                        clearInterval(countdown);
                        resetButton.disabled = false; // Enable the button after wait time
                        waitTimeMessage.textContent = ""; // Hide wait time message
                    }
                }, 1000);  // Update every second
            <?php endif; ?>

            // Add event listener to reset button to show the message on first click after countdown
            if (resetButton) {
                resetButton.addEventListener('click', function () {
                });
            }
        });
    </script>
</body>
</html>
