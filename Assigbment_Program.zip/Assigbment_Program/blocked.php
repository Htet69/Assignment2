<?php
session_start();

// Calculate remaining block time dynamically
$remainingTime = isset($_SESSION['remaining_time']) ? $_SESSION['remaining_time'] : 30;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blocked - Too Many Attempts</title>
    <link rel="stylesheet" href="css/style.css">
    <script>
        // Countdown timer with initial remaining time
        let countdown = <?php echo $remainingTime; ?>;
        
        function updateCountdown() {
            if (countdown <= 0) {
                window.location.href = "login.php"; 
            } else {
                document.getElementById('countdown').textContent = countdown;
                countdown--;
            }
        }

        // Update countdown every second
        setInterval(updateCountdown, 1000);
    </script>
</head>
<body>
<div class="container">
    <h2>Too Many Login Attempts</h2>
    <p>You have been temporarily blocked due to too many failed login attempts. Please wait for <span id="countdown"><?php echo $remainingTime; ?></span> seconds before trying again.</p>
</div>
</body>
</html>
