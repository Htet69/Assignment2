<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login if not authenticated
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Our Shop</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<nav>
    <a href="register.php">Register</a> | 
    <a href="login.php">Login</a> | 
    <a href="landing.php">Home</a>
</nav>

<body>
    <div class="container">
        <h2>Welcome to my landing page</h2>
        <p>Hello, <?php echo $_SESSION['username']; ?>! You Have Successfully Created An Account,Congratulation!</p>

        <p><a href="logout.php">Logout</a></p>
    </div>
</body>
</html>
