<?php
session_start();
include 'db_connection.php';

// Define max attempts before blocking and base block duration
$maxAttempts = 3;
$baseBlockDuration = 30; 
$additionalBlockTime = 15; 

// Initialize error message
$errorMessage = '';

// Check if user is blocked
if (isset($_SESSION['login_attempts']) && $_SESSION['login_attempts'] >= $maxAttempts) {
    $extraAttempts = $_SESSION['login_attempts'] - $maxAttempts;
    $totalBlockDuration = $baseBlockDuration + ($extraAttempts * $additionalBlockTime);
    
    // Calculate time since the last attempt
    $timeSinceLastAttempt = time() - $_SESSION['last_attempt_time'];

    // If the user is still in the block period, redirect to blocked.php
    if ($timeSinceLastAttempt < $totalBlockDuration) {
        $_SESSION['remaining_time'] = $totalBlockDuration - $timeSinceLastAttempt;
        header("Location: blocked.php");
        exit;
    } else {
        // Reset attempts if block duration has passed
        $_SESSION['login_attempts'] = 0; // Reset attempts
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $captcha_input = mysqli_real_escape_string($conn, $_POST['captcha_input'] ?? '');

    // Check if CAPTCHA input is correct
    if ($captcha_input !== $_SESSION['captcha']) {
        $errorMessage = "Incorrect CAPTCHA code!";
        incrementAttempts();
        header("Location: login.php?error=" . urlencode($errorMessage));
        exit;
    }

    // Query the database for the user
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Check if the email is verified
        if ($row['verified'] == 0) {
            $errorMessage = "Your email is not verified. Please check your email to verify your account.";
            header("Location: login.php?error=" . urlencode($errorMessage));
            exit;
        }

        // Verify the password
        if (password_verify($password, $row['password'])) {
            // Reset login attempts on successful login
            $_SESSION['login_attempts'] = 1; // Reset attempts
            $_SESSION['remaining_time'] = 1; // Reset remaining time
            $_SESSION['username'] = $username;
            header("Location: landing.php"); 
        } else {
            $errorMessage = "Invalid password!";
            incrementAttempts();
            header("Location: login.php?error=" . urlencode($errorMessage));
            exit;
        }
    } else {
        $errorMessage = "No user found with that username!";
        incrementAttempts();
        header("Location: login.php?error=" . urlencode($errorMessage));
        exit;
    }

    $conn->close();
}

function incrementAttempts() {
    if (!isset($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = 1;
    } else {
        $_SESSION['login_attempts']++;
    }
    $_SESSION['last_attempt_time'] = time(); 
}