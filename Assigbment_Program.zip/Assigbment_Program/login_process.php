<?php
session_start();
include 'db_connection.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

// Define max attempts before blocking and base block duration
$maxAttempts = 3;
$baseBlockDuration = 30; 
$additionalBlockTime = 15; 

// Initialize error message
$errorMessage = '';

// Check if user is blocked
if (isset($_SESSION['login_attempts']) && $_SESSION['login_attempts'] >= $maxAttempts) {
    $extraAttempts = $_SESSION['login_attempts'] - $maxAttempts;
    $totalBlockDuration = $baseBlockDuration + ($extraAttempts * $additionalBlockTime);
    
    $timeSinceLastAttempt = time() - $_SESSION['last_attempt_time'];

    if ($timeSinceLastAttempt < $totalBlockDuration) {
        $_SESSION['remaining_time'] = $totalBlockDuration - $timeSinceLastAttempt;
        header("Location: blocked.php");
        exit;
    } else {
        $_SESSION['login_attempts'] = 0; // Reset attempts
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $captcha_input = mysqli_real_escape_string($conn, $_POST['captcha_input'] ?? '');

    // Check if CAPTCHA input is correct
    if ($captcha_input !== $_SESSION['captcha']) {
        $errorMessage = "Incorrect CAPTCHA code!";
        incrementAttempts();
        header("Location: login.php?error=" . urlencode($errorMessage));
        exit;
    }

    // Query the database for the user
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Check if the email is verified
        if ($row['verified'] == 0) {
            $errorMessage = "Your email is not verified. Please check your email to verify your account.";
            header("Location: login.php?error=" . urlencode($errorMessage));
            exit;
        }

        // Verify the password
        if (password_verify($password, $row['password'])) {
            $_SESSION['login_attempts'] = 1; // Reset attempts
            $_SESSION['remaining_time'] = 1; // Reset remaining time
            $_SESSION['username'] = $username;

            // Generate OTP
            $otp = rand(100000, 999999);  // Generate a 6-digit OTP
            $_SESSION['otp'] = $otp;

            // Send OTP via PHPMailer
            $mail = new PHPMailer(true);
            try {
                //Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';  // Replace with your SMTP host
                $mail->SMTPAuth = true;
                $mail->Username = 'htetmyatpaswordrest@gmail.com';
                $mail->Password = 'vrmw dvtl akvn rnnl';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                //Recipients
                $mail->setFrom('htetmyatpaswordrest@gmail.com', 'Test App'); 
                $mail->addAddress($row['email']);
                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Your OTP for Login';
                $mail->Body    = "Your OTP for login is: <strong>$otp</strong>";

                $mail->send();
            } catch (Exception $e) {
                $errorMessage = "Could not send OTP. Please try again later.";
                incrementAttempts();
                header("Location: login.php?error=" . urlencode($errorMessage));
                exit;
            }

            // Show OTP modal or redirect to OTP page (after login success)
            $_SESSION['otp_sent'] = true;
            header("Location: otp_verification.php");  // Redirect to OTP verification page
            exit;
        } else {
            $errorMessage = "Invalid password!";
            incrementAttempts();
            header("Location: login.php?error=" . urlencode($errorMessage));
            exit;
        }
    } else {
        $errorMessage = "No user found with that username!";
        incrementAttempts();
        header("Location: login.php?error=" . urlencode($errorMessage));
        exit;
    }

    $conn->close();
}

function incrementAttempts() {
    if (!isset($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = 1;
    } else {
        $_SESSION['login_attempts']++;
    }
    $_SESSION['last_attempt_time'] = time(); 
}
?>
