<?php
session_start();

// Initialize attempt counter if it doesn't exist
if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 0;
}

// Initialize the delay time (in seconds)
$delay_time = 30; // 30 seconds initial delay

// Check if CAPTCHA is set, otherwise generate a new CAPTCHA
if (!isset($_SESSION['captcha'])) {
    $captcha_code = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 6);
    $_SESSION['captcha'] = $captcha_code;
}

// Check if user is locked out (after 5 failed attempts)
if ($_SESSION['attempts'] >= 5) {
    // Increase delay progressively after each failed attempt
    $delay_time += ($_SESSION['attempts'] - 4) * 10; // Increase by 10 seconds for each failed attempt over 5
    $lockout_message = "Too many attempts. Please try again in " . $delay_time . " seconds.";
} else {
    $lockout_message = "";
}

// Logic for clearing attempts after successful login
if (isset($_GET['reset']) && $_GET['reset'] == 'true') {
    unset($_SESSION['attempts']);
    unset($_SESSION['captcha']);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="container">
    <h2>Login to Your Account</h2>

    <?php
    if (isset($_GET['message'])) {
        echo "<div class='success-message'>" . htmlspecialchars($_GET['message']) . "</div>";
    }
    if (isset($_GET['error'])) {
        echo '<div style="color: red; border: 1px solid red; padding: 10px; margin-bottom: 10px; border-radius: 5px;">' . htmlspecialchars($_GET['error']) . '</div>';
    }

    // Display lockout message if too many failed attempts
    if ($lockout_message != "") {
        echo "<div style='color: red; border: 1px solid red; padding: 10px; margin-bottom: 10px; border-radius: 5px;'>" . $lockout_message . "</div>";
    }
    ?>

    <form action="login_process.php" method="post" id="loginForm">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <label>
            <input type="checkbox" id="showPassword"> Show Password
        </label><br><br>

        <label for="captcha">Please enter the CAPTCHA code below:</label><br>
        <canvas id="captchaCanvas" width="150" height="50"></canvas>
        <button type="button" id="refreshCaptcha" style="background: none; border: none;">
            <i class="fas fa-sync-alt"></i>
        </button>
        <br>
        <input type="text" id="captcha_input" name="captcha_input" required><br><br>

        <button type="submit">Login</button>
    </form>

    <p>Don't have an account? <a href="register.php">Register here</a></p>
    <p><a href="forgot_password.php">Forget Password</a></p>
</div>

<script>
    // Pass PHP-generated CAPTCHA to JavaScript
    let captchaText = "<?php echo $_SESSION['captcha']; ?>";

    const canvas = document.getElementById("captchaCanvas");
    const ctx = canvas.getContext("2d");

    // Draw the CAPTCHA code on the canvas
    function drawCaptcha(captchaText) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);  // Clear canvas before drawing new CAPTCHA
        ctx.font = "24px Arial";
        ctx.textAlign = "center";

        // Draw each character in a random color and position
        for (let i = 0; i < captchaText.length; i++) {
            ctx.fillStyle = `hsl(${Math.random() * 360}, 80%, 50%)`;
            ctx.fillText(captchaText[i], 25 + i * 20, 35 + Math.random() * 10);
        }

        // Draw random lines for distortion
        for (let i = 0; i < 5; i++) {
            ctx.strokeStyle = `hsl(${Math.random() * 360}, 70%, 40%)`;
            ctx.lineWidth = Math.random() * 2 + 1;
            ctx.beginPath();
            ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
            ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
            ctx.stroke();
        }
    }

    // Initial drawing of the CAPTCHA
    drawCaptcha(captchaText);

    // Event listener for refreshing the CAPTCHA
    document.getElementById("refreshCaptcha").addEventListener("click", () => {
        // Use AJAX to fetch a new CAPTCHA code from the server
        fetch('generate_captcha.php')
            .then(response => response.text())  // Get the new CAPTCHA code as plain text
            .then(newCaptcha => {
                captchaText = newCaptcha;  // Update the CAPTCHA text in JavaScript
                drawCaptcha(captchaText);  // Redraw the CAPTCHA with the new code
            })
            .catch(error => {
                console.error('Error refreshing CAPTCHA:', error);
            });
    });

    // Show/hide password functionality
    document.getElementById("showPassword").addEventListener("change", function() {
        const passwordField = document.getElementById("password");
        passwordField.type = this.checked ? "text" : "password";
    });

    window.onload = function() {
    // Manually clear the username and password fields
    document.getElementById("username").value = '';
    document.getElementById("password").value = '';

    // Ensure the CAPTCHA is refreshed
    fetch('generate_captcha.php')
        .then(response => response.text())  // Get a new CAPTCHA code from the server
        .then(newCaptcha => {
            captchaText = newCaptcha;  // Update the CAPTCHA text
            drawCaptcha(captchaText);  // Redraw the CAPTCHA
        })
        .catch(error => {
            console.error('Error refreshing CAPTCHA:', error);
        });
};

</script>
</body>
</html>
