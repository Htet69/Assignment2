<?php 
session_start();
include 'db_connection.php';

$errorMessage = '';
$successMessage = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    // Password strength check
    $hasNumber = preg_match('/[0-9]/', $new_password);
    $hasCapital = preg_match('/[A-Z]/', $new_password);
    $hasSpecial = preg_match('/[\W]/', $new_password);
    $isValidLength = strlen($new_password) >= 9;

    if (!($isValidLength && $hasNumber && $hasCapital && $hasSpecial)) {
        $errorMessage = "Password must be at least 9 characters long, include at least one capital letter, one number, and one special character.";
    } elseif ($new_password !== $confirm_password) {
        $errorMessage = "Passwords do not match.";
    } else {
        // Check if user exists
        $sql = "SELECT password FROM users WHERE email='$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $old_password = $user['password'];

            // Check if the new password is the same as the old password
            if (password_verify($new_password, $old_password)) {
                $errorMessage = "The new password cannot be the same as the old password.";
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

                // Update the user's password in the database
                $sql_update = "UPDATE users SET password='$hashed_password' WHERE email='$email'";
                if ($conn->query($sql_update) === TRUE) {
                    $successMessage = "Password has been reset successfully. Please log in with your new password.";
                } else {
                    $errorMessage = "Error updating password: " . $conn->error;
                }
            }
        } else {
            $errorMessage = "No user found with that email address.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<nav>
    <a href="register.php">Register</a> |
    <a href="login.php">Login</a> 
</nav>

<div class="container">
    <h2>Reset Password</h2>

    <?php if ($errorMessage): ?>
        <div style="color: red; border: 1px solid red; padding: 10px; margin-bottom: 10px; border-radius: 5px;">
            <?= htmlspecialchars($errorMessage); ?>
        </div>
    <?php endif; ?>

    <?php if ($successMessage): ?>
        <div style="color: green; border: 1px solid green; padding: 10px; margin-bottom: 10px; border-radius: 5px;">
            <?= htmlspecialchars($successMessage); ?>
        </div>
    <?php endif; ?>

    <form id="registerForm" action="" method="POST">
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required><br><br>
    
    <label for="new_password">New Password:</label>
    <input type="password" id="new_password" name="new_password" required>
    <div id="passwordStrength"></div>
    <ul class="password-requirements">
        <li><span id="lengthRequirement">❌</span> At least 9 characters</li>
        <li><span id="numberRequirement">❌</span> Contains a number</li>
        <li><span id="capitalRequirement">❌</span> Contains an uppercase letter</li>
        <li><span id="specialRequirement">❌</span> Contains a special character</li>
    </ul>
    
    <label for="confirm_password">Re-enter Password:</label>
    <input type="password" id="confirm_password" name="confirm_password" required>
    <div id="passwordMatchMessage"></div>
    <div id="passwordCriteriaError" style="color: red;"></div>
    <label>
        <input type="checkbox" id="showPassword"> Show Passwords
    </label><br><br>
    <button type="submit">Reset Password</button>
</form>


    <p>Remembered your password? <a href="login.php">Login here</a></p>
</div>

<script src="js/password_strength.js"></script>
<script>
    // Show/hide password functionality
    document.getElementById("showPassword").addEventListener("change", function() {
        const passwordField = document.getElementById("new_password");
        const confirmPasswordField = document.getElementById("confirm_password");
        
        if (this.checked) {
            passwordField.type = "text"; 
            confirmPasswordField.type = "text"; 
        } else {
            passwordField.type = "password"; 
            confirmPasswordField.type = "password"; 
        }
    });
</script>
</body>
</html>
